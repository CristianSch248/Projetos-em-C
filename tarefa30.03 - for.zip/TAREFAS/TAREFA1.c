#include <stdio.h>
#include <math.h>
int main(void)
{
 int i, num=0;

for(i=15; i<100; i++)

    printf("O quadrado do numero %d e: %d\n",i, i*i);
}
