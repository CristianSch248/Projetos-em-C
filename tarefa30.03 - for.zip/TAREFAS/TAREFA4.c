#include<stdio.h>
#include<math.h>

int main (void){

    int i, p;

    for(i=0; i<15; i++)
    {
        p = pow (3,i);
        printf("%d\n", p);
    }
}

