#include<stdio.h>

int main (void){
int i, a=1 , b=0, c;

    for(i = 0; i<15; i++)
      {
       printf("%d \n", c);
       c = a + b;
       b=a;
       a=c;
      }
}
