#include<stdio.h>

int main(void)
{

    int valor1, valor2;

    printf("informe o valor1: ");
    scanf("%d", &valor1);

    printf("informe o valor2: ");
    scanf("%d", &valor2);

    if(valor1 < valor2)
    {
        printf("%d", valor2);
    }

    else if
    (valor1 > valor2)
    {
        ;
        printf ("%d", valor1);
    }

}
