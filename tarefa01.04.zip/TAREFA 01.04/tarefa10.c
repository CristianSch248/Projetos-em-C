#include <stdio.h>
int main(void){
float m, j;

printf("informe uma metragem: \n");
scanf("%f", &m);

j = m/0.91;
printf("o seu numero transformado em jardas fica %.2f", j);

}
