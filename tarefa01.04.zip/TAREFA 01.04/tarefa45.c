#include<stdio.h>
int main (void){
float R1, R2, R3;

R1=780000*0.46;
printf("o primeiro recebera %.2f\n", R1);

R2=780000*0.32;
printf("o segundo recebera %.2f\n", R2);

R3=780000*0.22;
printf("o terceiro recebera %.2f\n", R3);
}
