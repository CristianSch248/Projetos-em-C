#include<stdio.h>
int main(void){
int i=10;

while(i>=0)
{
    printf("%d\n", i);
    i=i-1;
}
printf("FIM!");
}
