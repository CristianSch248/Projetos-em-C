#include<stdio.h>
int main(void){
int A, B, C;

printf("figite um numero para saber seu antecessor e sucessor: \n");
scanf("%d", &B);

A = B - 1;
C = B + 1;

printf("o antecessor do seu numero eh %d\n", A);
printf("o sucessor do seu numero eh %d", C);






}
