#include<stdio.h>
int main (void){
int i=3;

while(i<=15)
{
printf("%d\n", i);
i=i + 3;
}
}
