#include<stdio.h>
int main (void){
    int N, i=0, conta, R;

    printf("informe um numero:\n");
    scanf("%d", &N);

    while(i<N)
    {
        R=N/i;
        if() //resolver aqui
        {
            conta++;
            printf("o numero informado � divisival por %d\n", R);
        }
        i++;
    }
}
