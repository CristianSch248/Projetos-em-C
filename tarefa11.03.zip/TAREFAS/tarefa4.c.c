#include <stdio.h>

int main (void){
    int valor_1, valor_2, total_A, total_B;

        printf("informe valor_1: ");
            scanf("%d", &valor_1);

        printf("informe falor_2: ");
            scanf("%d", &valor_2);

        total_A = valor_1 + valor_2;
            printf("%d + %d = %d\n", valor_1, valor_2,  total_A);

        total_B = valor_1 - valor_2;
            printf("%d - %d = %d\n", valor_1, valor_2, total_B);

    }
