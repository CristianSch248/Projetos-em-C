#include <stdio.h>

int main (void){

    int valor_2;
    float valor_1, total;

    printf("informe o valor_1: ");
        scanf("%f", &valor_1);

    printf("informe o valor_2: ");
        scanf("%d", &valor_2);

    total = valor_1 * valor_2;
        printf("%.2f * %d = %.2f", valor_1, valor_2, total);







}
