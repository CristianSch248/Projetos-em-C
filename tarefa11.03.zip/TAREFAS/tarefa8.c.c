#include <stdio.h>
 int main (void){
    int X, A, B, C;

    printf("informe A: \n");
    scanf("%d", &A);

    printf ("informe B: \n");
    scanf("%d", &B);

    printf("informe C: \n");
    scanf("%d", &C);

    X = (A * B) / C;

    printf ("X: %d", X);

 }

