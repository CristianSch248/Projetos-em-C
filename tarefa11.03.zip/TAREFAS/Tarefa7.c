#include <stdio.h>

int main (void){
    int valor, resultado;
    printf ("informe um valor: \n");
    scanf ("%d", &valor);
    resultado = valor * 1;
    printf("%d * 1 = %d \n", valor, resultado);
    resultado = valor * 2;
    printf("%d * 2 = %d \n", valor, resultado);
    resultado = valor * 3;
    printf("%d * 3 = %d \n", valor, resultado);
    resultado = valor * 4;
    printf("%d * 4 = %d \n", valor, resultado);
    resultado = valor * 5;
    printf("%d * 5 = %d \n", valor, resultado);
    resultado = valor * 6;
    printf("%d * 6 = %d \n", valor, resultado);
    resultado = valor * 7;
    printf("%d * 7 = %d \n", valor, resultado);
    resultado = valor * 8;
    printf("%d * 8 = %d \n", valor, resultado);
    resultado = valor * 9;
    printf("%d * 9 = %d \n", valor, resultado);
    resultado = valor * 10;
    printf("%d * 10 = %d \n", valor, resultado);
}
