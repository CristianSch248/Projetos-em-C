#include <stdio.h>
int main (void){
    int valor_1, valor_2;
    printf("informe o valor_1 ");
    scanf ("%d", &valor_1);

    printf("informe o valor_2 ");
    scanf("%d", &valor_2 );

    printf("valor_2 = %d", valor_2);


    }
