#include <stdio.h>

int main(void)
{
	int A[4][5];
	int B[4][5];
	int C[4][5];
	
	int l=0, c=0, n=0;
	
	while(l<4 && c<5)
	{
		
		
		
		
	}
	
	
	
	
	
	
}
